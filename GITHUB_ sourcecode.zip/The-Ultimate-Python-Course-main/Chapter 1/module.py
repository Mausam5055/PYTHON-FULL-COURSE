import pyjokes

# print("Printing Jokes...")

# This prints a random joke
joke = pyjokes.get_joke()
print(joke)


# so thanks
# that was my program
# another line
# Yet another line