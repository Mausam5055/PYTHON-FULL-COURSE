for i in range(645):
    pass



i = 0
while(i<45):
    print(i)
    i += 1