import pyttsx3
engine = pyttsx3.init()
engine.say("Hey I am good")
engine.runAndWait()