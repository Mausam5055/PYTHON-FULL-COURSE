a = (1,45,342,3424,False, "Rohan", "Shivam")
print(a)
print(type(a))