a = 23

aaa = 435

harry = 34

sameer = 45

_samerr = 34

# @sameer = 56 # Invalid due to @ symbol
# s@meer # Invalid due to @ symbol