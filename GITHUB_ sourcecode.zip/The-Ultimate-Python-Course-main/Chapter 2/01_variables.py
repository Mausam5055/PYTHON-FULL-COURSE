a = 1

b = 2

c = 7

name = "harry"

print(a + b)