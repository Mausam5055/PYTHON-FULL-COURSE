a = "{1} is a good {0}".format("harry", "boy")

print(a)