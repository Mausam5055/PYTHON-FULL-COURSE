a = ["Harry", "Rohan", "Shubham"]

final = "::".join(a)
print(final)