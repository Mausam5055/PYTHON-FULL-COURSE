# def square(n):
#     return n*n 

square = lambda x: x*x

print(square(5))