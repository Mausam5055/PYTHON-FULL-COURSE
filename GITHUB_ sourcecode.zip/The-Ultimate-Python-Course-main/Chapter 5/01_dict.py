d = {} # Empty dictionary
marks = {
    "Harry": 100,
    "Shubham": 56,
    "Rohan": 23
}


# print(marks, type(marks))
print(marks["Harry"])