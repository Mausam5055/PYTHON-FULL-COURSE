from module import myFunc

