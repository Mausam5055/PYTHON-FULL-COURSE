# pip freeze > requirements.txt
# virtualenv harryenv