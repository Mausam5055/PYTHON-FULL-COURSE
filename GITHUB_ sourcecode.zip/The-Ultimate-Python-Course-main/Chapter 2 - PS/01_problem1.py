a = 1

b = 5

print(a + b)