a = int(input("Enter number 1: "))
b = int(input("Enter number 2: "))

print("a is greater than b is", a>b)