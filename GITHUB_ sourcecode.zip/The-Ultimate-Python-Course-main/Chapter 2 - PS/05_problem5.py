a = int(input("Enter number 1: "))
b = int(input("Enter number 2: "))


print("The average of these two number is", (a+b)/2)