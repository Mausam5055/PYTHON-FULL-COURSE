def goodDay():
    print("Good Day")

goodDay()