name = "Harry is a good  boy and  "

print(name.find("  "))