import pyautogui

while True:
    a = pyautogui.position()
    print(a)
    # 1639, 1412
    # 1003 237 to 2187 1258
    # 1026 244
    # to 1131 1321