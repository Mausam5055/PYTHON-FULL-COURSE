st = "Hey Harry you are amazing"

f = open("myfile.txt", "a")

f.write(st)

f.close()