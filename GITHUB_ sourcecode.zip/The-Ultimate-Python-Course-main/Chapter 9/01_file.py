'''
a = "a very long string with emails"

emails = []
3 seconds
'''

f = open("file.txt", "r")
data = f.read()
print(data)
f.close()