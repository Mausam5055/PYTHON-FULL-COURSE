st = "Hey Harry you are amazing"

f = open("myfile.txt", "w")

f.write(st)

f.close()